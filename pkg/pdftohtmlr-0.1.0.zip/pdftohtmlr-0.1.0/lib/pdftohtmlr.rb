module PDFToHTMLR
  class PDFToHTMLRError < RuntimeError; end
  
  VERSION = '0.1.0'
  
  class PdfFile
    attr :path
    attr :output
    
  end
end
